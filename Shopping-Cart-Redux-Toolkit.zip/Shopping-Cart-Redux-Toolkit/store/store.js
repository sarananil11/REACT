import { configureStore } from '@reduxjs/toolkit'
import productReducer from '../slices/productSlice'
// import cartReducer from '../slices/cartSlice'
import React from 'react'

const store = configureStore({
    reducer:{
        products: productReducer,
        //cart: cartReducer,

    },
});

export default store
